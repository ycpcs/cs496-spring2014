package edu.ycp.cs.cs496.cs496_lecture12;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class ViewThread extends Thread {
	private Panel mPanel;
	private SurfaceHolder mHolder;
	private boolean mRun = false;
	private long mStartTime;
	private long mElapsed;
	
	public ViewThread(Panel panel) {
		mPanel = panel;
		mHolder = mPanel.getHolder();
	}
	
	public void setRunning(boolean run) {
		mRun = run;
	}
	
	@Override
	public void run() {
		Canvas canvas = null;
		mStartTime = System.currentTimeMillis();
		while (mRun) {
			canvas = mHolder.lockCanvas();
			if (canvas != null) {
				mElapsed = System.currentTimeMillis() - mStartTime;
				mPanel.update(mElapsed);
				mPanel.doDraw(canvas,mElapsed);
				mHolder.unlockCanvasAndPost(canvas);
			}
			mStartTime = System.currentTimeMillis();
		}
	}
}
