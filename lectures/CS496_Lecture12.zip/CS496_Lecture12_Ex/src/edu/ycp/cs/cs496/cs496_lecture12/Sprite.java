package edu.ycp.cs.cs496.cs496_lecture12;

import java.util.Random;

import edu.ycp.cs.cs496.cs496_lab12.R;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Sprite {
	private float mX;
	private float mY;
	private int mDx;
	private int mDy;
	private Bitmap mBitmap;
	
	public Sprite(Resources res, int x, int y) {
		Random rand = new Random();
		mBitmap = BitmapFactory.decodeResource(res, R.drawable.ball_sprite);
		mX = x - mBitmap.getWidth()/2;
		mY = y - mBitmap.getHeight()/2;
		mDx = rand.nextInt(7) - 3;
		mDy = rand.nextInt(7) - 3;
	}
	
	public void doDraw(Canvas canvas) {
		canvas.drawBitmap(mBitmap, mX, mY, null);
	}
	
	public void update(long elapsedTime) {
		mX += mDx * (elapsedTime / 20f);
		mY += mDy * (elapsedTime / 20f);
		checkBoundary();
	}
	
	private void checkBoundary() {
		if (mX <= 0) {
			mDx *= -1;
			mX = 0;
		} else if (mX + mBitmap.getWidth() >= Panel.mWidth) {
			mDx *= -1;
			mX = Panel.mWidth - mBitmap.getWidth();
		}
		
		if (mY <= 0) {
			mDy *= -1;
			mY = 0;
		} else if (mY + mBitmap.getHeight() >= Panel.mHeight) {
			mDy *= -1;
			mY = Panel.mHeight - mBitmap.getHeight();
		}
	}
}
