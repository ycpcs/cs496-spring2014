package edu.ycp.cs.cs496.cs496_lab12;

import java.util.ArrayList;
import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class Panel extends SurfaceView implements Callback {
	private Sprite ball;
	private ViewThread mThread;
	public static float mWidth;
	public static float mHeight;
	private Paint mPaint;
	private boolean gameOver;
	private float previousX;
	private float previousY;
	final private float holeRadius = 20.0f;
	final private float ballStopped = 0.1f;

	public Panel(Context context) {
		super(context);
		getHolder().addCallback(this);
		mThread = new ViewThread(this);
		mPaint = new Paint();
		mPaint.setColor(Color.WHITE);
		gameOver = false;
		Random r = new Random();
		ball = new Sprite(getResources(), 0, 0,r.nextInt(7)-3,r.nextInt(7)-3);
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		mWidth = width;
		mHeight = height;
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		if (!mThread.isAlive()) {
			mThread = new ViewThread(this);
			mThread.setRunning(true);
			mThread.start();
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		if (mThread.isAlive()) {
			mThread.setRunning(false);
		}
	}

	public void update(long elapsedTime) {
		synchronized(ball) {
			ball.update(elapsedTime);
		}
		gameOver = checkGameEnd();
	}
	
	public void doDraw(Canvas canvas, long elapsed) {
		canvas.drawColor(Color.BLACK);
		canvas.drawCircle(mWidth/2, mHeight/2, holeRadius, mPaint);
		synchronized(ball) {
			ball.doDraw(canvas);
		}

		if (gameOver) {
			canvas.drawText("YOU WON!",10, 10, mPaint);
		}
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
	      float currentX = event.getX();
	      float currentY = event.getY();
	      float deltaX, deltaY;
	      float scalingFactor = 5.0f / ((mWidth > mHeight) ? mWidth : mHeight);
	      switch (event.getAction()) {
	         case MotionEvent.ACTION_MOVE:
	            // Modify rotational angles according to movement
	            deltaX = currentX - previousX;
	            deltaY = currentY - previousY;
	            ball.changeVelocity(deltaX * scalingFactor, deltaY * scalingFactor);
	      }
	      // Save current x, y
	      previousX = currentX;
	      previousY = currentY;
	      return true;  // Event handled
	}

	private boolean checkGameEnd() {
		float dist = distance(ball.getCenterX(),ball.getCenterY(),mWidth/2, mHeight/2);
		float vel = (float) Math.sqrt(ball.getXVelocity()*ball.getXVelocity() + ball.getYVelocity()*ball.getYVelocity());
		if ((dist < holeRadius-ball.getWidth()) && (vel < ballStopped)) {
			return true;
		}
		return false;
	}

	private float distance(float x1, float y1, float x2, float y2) {
		return (float) Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	}
	
}
