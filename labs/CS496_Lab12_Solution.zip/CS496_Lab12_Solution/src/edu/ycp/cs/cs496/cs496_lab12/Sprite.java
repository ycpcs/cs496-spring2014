package edu.ycp.cs.cs496.cs496_lab12;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Sprite {
	private float mX;
	private float mY;
	private float mDx;
	private float mDy;
	private Bitmap mBitmap;
	
	public Sprite(Resources res, float x, float y, float dx, float dy) {
		mBitmap = BitmapFactory.decodeResource(res, R.drawable.ball_sprite);
		mX = x - mBitmap.getWidth()/2;
		mY = y - mBitmap.getHeight()/2;
		mDx = dx;
		mDy = dy;
	}
	
	public void update(long elapsedTime) {
		mX += mDx * (elapsedTime / 20f);
		mY += mDy * (elapsedTime / 20f);
		checkBoundary();
	}

	public void doDraw(Canvas canvas) {
		canvas.drawBitmap(mBitmap, mX, mY, null);
	}
		
	private void checkBoundary() {
		if (mX <= 0) {
			mDx *= -1;
			mX = 0;
		} else if (mX + mBitmap.getWidth() >= Panel.mWidth) {
			mDx *= -1;
			mX = Panel.mWidth - mBitmap.getWidth();
		}
		
		if (mY <= 0) {
			mDy *= -1;
			mY = 0;
		} else if (mY + mBitmap.getHeight() >= Panel.mHeight) {
			mDy *= -1;
			mY = Panel.mHeight - mBitmap.getHeight();
		}
	}
	
	public void changeVelocity(float ddx, float ddy) {
		mDx += ddx;
		mDy += ddy;
	}
	
	// Getter methods
	
	public float getCenterX() {
		return mX + mBitmap.getWidth()/2;
	}
	
	public float getCenterY() {
		return mY + mBitmap.getHeight()/2;
	}
	
	public float getWidth() {
		return mBitmap.getWidth()/2;
	}
	
	public float getHeight() {
		return mBitmap.getHeight()/2;
	}
	
	public float getXVelocity() {
		return mDx;
	}
	
	public float getYVelocity() {
		return mDy;
	}

}
