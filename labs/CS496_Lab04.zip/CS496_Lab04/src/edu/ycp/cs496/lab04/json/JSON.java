package edu.ycp.cs496.lab04.json;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JSON {
	private static final ObjectMapper theObjectMapper = new ObjectMapper();
	
	public static ObjectMapper getObjectMapper() {
		return theObjectMapper;
	}
}
