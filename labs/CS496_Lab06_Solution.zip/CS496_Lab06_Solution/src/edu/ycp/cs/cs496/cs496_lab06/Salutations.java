package edu.ycp.cs.cs496.cs496_lab06;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Salutations extends Activity {

	   @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main_rel);
	 
	        title = "";
	        salutationMsg = "";
	                
	        // Populate spinner
	        Spinner titleSpinner = (Spinner) findViewById(R.id.titleSpinner);
	        ArrayAdapter<CharSequence> titleAdapter = ArrayAdapter.createFromResource(
	                this, R.array.titles, android.R.layout.simple_spinner_item);
	        titleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	        titleSpinner.setAdapter(titleAdapter);
	        titleSpinner.setOnItemSelectedListener(new TitleSelectedListener());
	        
	        // Button callback
	        final Button button = (Button) findViewById(R.id.salutationButton);
	        button.setOnClickListener(new View.OnClickListener() {
	                @Override
	                public void onClick(View v) {
	                	// Check name CheckBoxes
	                	CheckBox cbFirst = (CheckBox) findViewById(R.id.firstNameCheck);
	                	CheckBox cbLast = (CheckBox) findViewById(R.id.lastNameCheck);

	                	// Get first name text
	        			EditText firstName = (EditText) findViewById(R.id.firstName);
	        			String firstNameStr = firstName.getText().toString();
	        			// Add space after first name
	        			if (!firstNameStr.isEmpty()) {
	        				firstNameStr = firstNameStr + " ";
	        			}
	        			
	        			// Get last name text
	          			EditText lastName = (EditText) findViewById(R.id.lastName);
	          			String lastNameStr = lastName.getText().toString();

	          			// Check for errors
	           			if (!cbFirst.isChecked() && !cbLast.isChecked()) {
	                		Toast.makeText(Salutations.this, "Error: No names selected", Toast.LENGTH_SHORT).show();
	                	} else if (cbFirst.isChecked() && firstNameStr.isEmpty()){
	                		Toast.makeText(Salutations.this, "Error: No first name", Toast.LENGTH_SHORT).show();
	                	} else if (cbLast.isChecked() && lastNameStr.isEmpty()){
	                		Toast.makeText(Salutations.this, "Error: No last name", Toast.LENGTH_SHORT).show();
	                	} else {               		
	                		// Clear first name if unchecked
	                		if (!cbFirst.isChecked()) {
	                			firstNameStr = "";
	                		}
	                		// Clear last name if unchecked
	                		if (!cbLast.isChecked()) {
	                			lastNameStr = "";
	                		}
	                		
	                		// Construct toast message for salutation
	                		String msg = salutationMsg + ",\n" +
	                				 title + firstNameStr + lastNameStr;
	                		Toast.makeText(Salutations.this, msg, Toast.LENGTH_LONG).show();
	                	}
	                }
	        });
	    }
	    
	    private String title;
	    private String salutationMsg;
	    
	    public void onFirstNameClicked(View v) {
	        // Check if box is set or not
	    	CheckBox cb = (CheckBox) v;
	        if (cb.isChecked()) {
	        	
	        } else {
	            
	        }
	    }
	    
	    public void onLastNameClicked(View v) {
	        // Check if box is set or not
	        CheckBox cb = (CheckBox) v;
	        if (cb.isChecked()) {
	        	
	        } else {
	            
	        }
	    }

	    public void onSalutationClicked(View v) {
	        // Get radio button selected
	        RadioButton rb = (RadioButton) v;
	        // Perform appropriate action for selected option
	        salutationMsg = rb.getText().toString();
	    }    
	    
	    public class TitleSelectedListener implements OnItemSelectedListener {
	        // Item selected
	        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
	        	// Do something with selected object using
	        	title = "";
	        	if (pos != 0) {
	        		title = parent.getItemAtPosition(pos).toString() + " ";
	        	}
	        }

	        // Nothing selected
	        public void onNothingSelected(AdapterView<?> parent) {
	            // Do whatever necessary if no item selected
	        	title = "";
	        }
	    }
}
