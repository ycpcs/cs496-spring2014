package edu.ycp.cs.cs496.cs496_lab13;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class OpenGLSurfaceView extends GLSurfaceView {

	public OpenGLSurfaceView(Context context){
        super(context);
   }

}
