package edu.ycp.cs.cs496.cs496_lab13;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class BasicOpenGL extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}


}
