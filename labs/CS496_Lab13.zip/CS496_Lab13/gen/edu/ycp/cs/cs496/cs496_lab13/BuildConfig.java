/** Automatically generated file. DO NOT MODIFY */
package edu.ycp.cs.cs496.cs496_lab13;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}