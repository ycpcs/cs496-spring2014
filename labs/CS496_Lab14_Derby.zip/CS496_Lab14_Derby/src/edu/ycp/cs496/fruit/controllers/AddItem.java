package edu.ycp.cs496.fruit.controllers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.ycp.cs496.fruit.model.Item;
import edu.ycp.cs496.fruit.model.persist.DatabaseProvider;

public class AddItem {
	private static Pattern ITEM_NAME_PATTERN = Pattern.compile("^[A-Za-z]+$"); 
	
	public static boolean isLegalItemName(String itemName) {
		Matcher m = ITEM_NAME_PATTERN.matcher(itemName);
		return m.matches();
	}
	
	public boolean addItem(Item item) {
		if (!isLegalItemName(item.getName())) {
			throw new IllegalArgumentException("Illegal item name: " + item.getName());
		}
		return DatabaseProvider.getInstance().addItem(item);
	}
}
