package edu.ycp.cs496.fruit.controllers;

import edu.ycp.cs496.fruit.model.Item;
import edu.ycp.cs496.fruit.model.persist.DatabaseProvider;
import edu.ycp.cs496.fruit.model.persist.IDatabase;

/**
 * Controller to get an {@link Item} given the item name.
 */
public class GetItemByName {
	public Item getItem(String itemName) {
		IDatabase db = DatabaseProvider.getInstance();
		return db.getItem(itemName);
	}
}
