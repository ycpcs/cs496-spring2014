package edu.ycp.cs496.fruit.model.persist;

/**
 * Allow access to the singleton {@link IDatabase} implementation.
 */
public class DatabaseProvider {
	private static IDatabase theInstance;
	
	/**
	 * Set the instance of {@link IDatabase} that should be used
	 * for invoking persistence operations.
	 * 
	 * @param db the {@link IDatabase} instance
	 */
	public static void setInstance(IDatabase db) {
		theInstance = db;
	}
	
	/**
	 * Get the singleton {@link IDatabase} implementation.
	 * 
	 * @return the singleton {@link IDatabase} implementation
	 */
	public static IDatabase getInstance() {
		return theInstance;
	}
}
