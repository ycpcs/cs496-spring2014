package edu.ycp.cs496.fruit.model.persist;

import java.util.List;

import edu.ycp.cs496.fruit.model.Item;

/**
 * Persistence operations for fruit web service.
 */
public interface IDatabase {
	/**
	 * Get a single {@link Item} for the given item name.
	 * 
	 * @param itemName the item name
	 * @return the {@link Item}, or null if there is no such item
	 */
	public Item getItem(String itemName);
	
	/**
	 * Get the current inventory (list of {@link Item}s.
	 * 
	 * @return the current inventory (list of {@link Item}s
	 */
	public List<Item> getInventory();

	/**
	 * Add given {@link Item} to database.
	 * 
	 * @param item the {@link Item} to add.
	 * @return true if the item was added successfully, false if the item
	 *         couldn't be added because it already exists
	 */
	public boolean addItem(Item item);
}
