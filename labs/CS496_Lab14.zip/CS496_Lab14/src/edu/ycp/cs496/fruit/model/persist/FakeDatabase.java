package edu.ycp.cs496.fruit.model.persist;

import java.util.ArrayList;
import java.util.List;

import edu.ycp.cs496.fruit.model.Item;

/**
 * Implementation of the {@link IDatabase} interface that stores
 * objects using in-memory data structures.  It doesn't
 * provide actual persistence, but is useful as a proof
 * of concept.
 */
public class FakeDatabase implements IDatabase {
	private int nextItemId;
	private List<Item> inventory;
	
	public FakeDatabase() {
		nextItemId = 1;
		inventory = new ArrayList<Item>();
		
		// Populate initial inventory
		addItem(new Item("Apples", 3));
		addItem(new Item("Oranges", 7));
		addItem(new Item("Pomegranates", 55));
	}
	
	@Override
	public Item getItem(String itemName) {
		for (Item item : inventory) {
			if (item.getName().equals(itemName)) {
				// return a copy
				return new Item(item.getName(), item.getQuantity());
			}
		}
		
		// no such item
		return null;
	}
	
	@Override
	public boolean addItem(Item item) {
		// Make sure an item with the same name doesn't already exist
		if (getItem(item.getName()) != null) {
			return false;
		}
		
		// Assign a unique id
		item.setId(nextItemId++);
		
		// Add a copy of the object to the list
		inventory.add(item.clone());
		
		return true;
	}

	@Override
	public List<Item> getInventory() {
		// return a copy
		return new ArrayList<Item>(inventory);
	}
}
