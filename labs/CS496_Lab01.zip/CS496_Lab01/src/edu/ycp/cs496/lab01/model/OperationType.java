package edu.ycp.cs496.lab01.model;

public enum OperationType {
	ADDITION,
	SUBTRACTION,
	MULTIPLICATION,
	DIVISION,
}
