package edu.ycp.cs496.lab01.controllers;

import edu.ycp.cs496.lab01.model.Operation;
import edu.ycp.cs496.lab01.model.Result;

public class PerformOperation {
	public Result perform(Operation operation) {
		double value;
		switch (operation.getOperationType()) {
		case ADDITION:
			value = operation.getFirst() + operation.getSecond();
			break;
		case SUBTRACTION:
			value = operation.getFirst() - operation.getSecond();
			break;
		case MULTIPLICATION:
			value = operation.getFirst() * operation.getSecond();
			break;
		case DIVISION:
			value = operation.getFirst() / operation.getSecond();
			break;
		default:
			throw new UnsupportedOperationException("Unknown operation type: " + operation.getOperationType());
		}
		
		Result result = new Result();
		result.setValue(value);
		return result;
	}
}
