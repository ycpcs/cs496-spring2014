package edu.ycp.cs496.lab01.model;

public class Operation {
	private OperationType operationType;
	private double first;
	private double second;
	
	public Operation() {
		
	}
	
	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}
	
	public OperationType getOperationType() {
		return operationType;
	}
	
	public void setFirst(double first) {
		this.first = first;
	}
	
	public double getFirst() {
		return first;
	}
	
	public void setSecond(double second) {
		this.second = second;
	}
	
	public double getSecond() {
		return second;
	}
}
