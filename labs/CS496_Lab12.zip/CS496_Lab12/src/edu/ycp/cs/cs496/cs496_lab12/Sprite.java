package edu.ycp.cs.cs496.cs496_lab12;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;

public class Sprite {
	private float mX;
	private float mY;
	private float mDx;
	private float mDy;
	private Bitmap mBitmap;
	
	public Sprite(Resources res, float x, float y, float dx, float dy) {
		//TODO: Initialize class fields
	}
	
	public void update(long elapsedTime) {
		// TODO: Update position and check boundary collisions
	}

	public void doDraw(Canvas canvas) {
		// TODO: Draw sprite bitmap
	}
		
	private void checkBoundary() {
		// TODO: Reverse velocity if boundary collision
	}
	
	// Velocity update method
	public void changeVelocity(float ddx, float ddy) {
		mDx += ddx;
		mDy += ddy;
	}
	
	// Getter methods
	
	public float getCenterX() {
		return mX + mBitmap.getWidth()/2;
	}
	
	public float getCenterY() {
		return mY + mBitmap.getHeight()/2;
	}
	
	public float getWidth() {
		return mBitmap.getWidth()/2;
	}
	
	public float getHeight() {
		return mBitmap.getHeight()/2;
	}
	
	public float getXVelocity() {
		return mDx;
	}
	
	public float getYVelocity() {
		return mDy;
	}

}
