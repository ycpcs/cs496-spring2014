package edu.ycp.cs.cs496.cs496_lab12;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class Panel extends SurfaceView implements Callback {
	public static float mWidth;
	public static float mHeight;
	private float previousX;
	private float previousY;
	final private float holeRadius = 20.0f;
	final private float ballStopped = 0.1f;
	// TODO: Add class fields
	
	public Panel(Context context) {
		super(context);
		// TODO: Initialize class fields
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		mWidth = width;
		mHeight = height;
	}

	public void surfaceCreated(SurfaceHolder holder) {
		// TODO: Start thread
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO: Stop thread
	}

	public void update(long elapsedTime) {
		// TODO: Update ball (thread safe) and check end of game
	}
	
	public void doDraw(Canvas canvas, long elapsed) {
		canvas.drawColor(Color.BLACK);

		// TODO: Draw hole

		// TODO: Draw ball (thread safe)
		
		// TODO: Display message if game over
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO: Update velocity based on swipe gesture
		
		return true;  // Event handled
	}

	private boolean checkGameEnd() {
		// TODO: Check if ball is within hole region
		
		return false;
	}

	private float distance(float x1, float y1, float x2, float y2) {
		return (float) Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	}
	
}
