package edu.ycp.cs.cs496.cs496_lab12;

import android.graphics.Canvas;

public class ViewThread extends Thread {
	// TODO: Add class fields
	private boolean mRun = false;
	
	public ViewThread(Panel panel) {
		// TODO: Initialize panel and holder objects
	}
	
	public void setRunning(boolean run) {
		mRun = run;
	}
	
	@Override
	public void run() {
		Canvas canvas = null;
		// TODO: Update and draw with thread safe canvas
	}
}
