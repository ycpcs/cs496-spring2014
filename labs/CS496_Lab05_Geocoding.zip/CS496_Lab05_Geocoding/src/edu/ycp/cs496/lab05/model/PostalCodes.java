package edu.ycp.cs496.lab05.model;

import java.util.List;

public class PostalCodes {
	List<PostalCode> postalCodes;
	
	PostalCodes(){};
	
	public void setPostalCodes(List<PostalCode> postalCodes) {
		this.postalCodes = postalCodes;
	}
	
	public List<PostalCode> getPostalCodes() {
		return postalCodes;
	}
}
