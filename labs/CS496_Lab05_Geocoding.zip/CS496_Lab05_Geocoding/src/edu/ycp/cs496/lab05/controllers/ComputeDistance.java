package edu.ycp.cs496.lab05.controllers;

import edu.ycp.cs496.lab05.model.PostalCode;
import edu.ycp.cs496.lab05.model.Result;

public class ComputeDistance {
	public Result findDistance(PostalCode p1, PostalCode p2) {
		
		double lat1 = p1.getLat();
		double lat2 = p2.getLat();
		
		double lng1 = p1.getLng();
		double lng2 = p2.getLng();
		
		Double value = 3956 * 2 * Math.asin(
	            Math.sqrt(
	                    Math.pow(Math.sin((lat1 - lat2)*Math.PI / 180 / 2), 2) +
	                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat1 * Math.PI / 180) *
	                    Math.pow(Math.sin((lng1 - lng2) * Math.PI / 180 / 2), 2)));

		
		Result result = new Result();
		result.setValue(value);
		return result;
	}
}
