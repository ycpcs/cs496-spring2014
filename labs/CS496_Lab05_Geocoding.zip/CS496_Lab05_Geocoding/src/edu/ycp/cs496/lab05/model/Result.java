package edu.ycp.cs496.lab05.model;

public class Result {
	private double value;
	
	public Result() {
		
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	public double getValue() {
		return value;
	}
}
