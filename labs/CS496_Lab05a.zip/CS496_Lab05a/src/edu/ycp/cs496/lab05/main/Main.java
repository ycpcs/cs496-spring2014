package edu.ycp.cs496.lab05.main;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import edu.ycp.cs496.lab05.controllers.ComputeDistance;
import edu.ycp.cs496.lab05.json.JSON;
import edu.ycp.cs496.lab05.model.PostalCode;
import edu.ycp.cs496.lab05.model.PostalCodes;
import edu.ycp.cs496.lab05.model.Result;

public class Main {	
	public static void main(String[] args) throws Exception {
		// You won't need to change anything in the main method.
		
		Scanner keyboard = new Scanner(System.in);

		System.out.print("First street address: ");
		String addr1 = keyboard.nextLine();
		System.out.print("First zip code      : ");
		String zip1 = keyboard.nextLine();
		
		System.out.print("Second street address: ");
		String addr2 = keyboard.nextLine(); 
		System.out.print("Second zip code      : ");
		String zip2 = keyboard.nextLine();
		
		PostalCode loc1 = geocode(addr1, zip1);
		
		PostalCode loc2 = geocode(addr2, zip2);
		
		ComputeDistance cd = new ComputeDistance();
		Result r = cd.findDistance(loc1, loc2);
		
		System.out.printf("Distance is %.2f miles\n", r.getValue());
	}
	
	public static PostalCode geocode(String addr, String zip) throws URISyntaxException, ClientProtocolException, IOException, IllegalStateException {

		String host = "api.geonames.org";
		int port = -1; // use default port
		
		HttpClient client = new DefaultHttpClient();
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		// TODO: add query parameters
		
		String query = URLEncodedUtils.format(params, "UTF-8");
		
		// TODO: create a URI
		// protocol is "http"
		// host and port as specified by variables above
		// path is "/postalCodeSearchJSON"
		// query is created from the query params (as specified above)
		
		// TODO: create an HttpGet request object from the URI
		
		// TODO: use the HttpClient to execute the request to produce an HttpResponse
		
		// TODO: get the HttpEntity from the response
		
		// TODO: decode the body of the response as a JSON encoding of a PostalCodes object
		
		// TODO: return the first PostalCode in the PostalCodes object
		
		throw new UnsupportedOperationException("TODO - implement");
	}
}
