package edu.ycp.cs496.lab01.main;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import edu.ycp.cs496.lab01.controllers.ComputeDistance;
import edu.ycp.cs496.lab01.json.JSON;
import edu.ycp.cs496.lab01.model.PostalCode;
import edu.ycp.cs496.lab01.model.PostalCodes;
import edu.ycp.cs496.lab01.model.Result;

public class Main {	
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		System.out.print("First street address: ");
		String addr1 = keyboard.nextLine();
		System.out.print("First zip code      : ");
		String zip1 = keyboard.nextLine();

		
		System.out.print("Second street address: ");
		String addr2 = keyboard.nextLine(); 
		System.out.print("Second zip code      : ");
		String zip2 = keyboard.nextLine();
		
		
		PostalCode loc1 = geocode(addr1, zip1);
		
		PostalCode loc2 = geocode(addr2, zip2);
		
		ComputeDistance cd = new ComputeDistance();
		Result r = cd.findDistance(loc1, loc2);

		
		System.out.printf("Distance is %.2f miles\n", r.getValue());
	}
	

	public static PostalCode geocode(String addr, String zip) throws URISyntaxException, ClientProtocolException, IOException, IllegalStateException {

		String host = "api.geonames.org";
		
		HttpClient client = new DefaultHttpClient();
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		//params.add(new BasicNameValuePair("num", String.valueOf(num)));
		params.add(new BasicNameValuePair("postalcode", zip));
		params.add(new BasicNameValuePair("placeName", addr));
		params.add(new BasicNameValuePair("country", "US"));
		params.add(new BasicNameValuePair("username","ycpcs_cs496"));
		
		// Uncomment these lines to use an HTTP GET request
		URI uri = URIUtils.createURI("http", host, -1, "/postalCodeSearchJSON", 
			    URLEncodedUtils.format(params, "UTF-8"), null);
		HttpGet request = new HttpGet(uri);

		// Uncomment these lines to use an HTTP POST request
//		HttpPost request = new HttpPost("http://" + host + "/isPrime");
//		request.setEntity(new UrlEncodedFormEntity(params));

		HttpResponse response = client.execute(request);

		// Copy the response body to a string
		HttpEntity entity = response.getEntity();

		PostalCodes p = JSON.getObjectMapper().readValue(entity.getContent(), PostalCodes.class);		
		
		return p.getPostalCodes().get(0);
	}
}
