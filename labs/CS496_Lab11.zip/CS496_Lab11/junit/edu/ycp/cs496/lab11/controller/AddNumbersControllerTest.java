package edu.ycp.cs496.lab11.controller;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs496.lab11.controller.AddNumbersController;

public class AddNumbersControllerTest {
	private AddNumbersController controller;
	
	@Before
	public void setUp() {
		controller = new AddNumbersController();
	}
	
	@Test
	public void testAddNumbers() {
		assertEquals((Double) 7.0, controller.add(3.0, 4.0));
	}
}
