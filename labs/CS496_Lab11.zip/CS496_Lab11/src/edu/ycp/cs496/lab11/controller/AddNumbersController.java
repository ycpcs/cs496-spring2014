package edu.ycp.cs496.lab11.controller;

public class AddNumbersController {
	public Double add(Double first, Double second) {
		return first + second;
	}
}
