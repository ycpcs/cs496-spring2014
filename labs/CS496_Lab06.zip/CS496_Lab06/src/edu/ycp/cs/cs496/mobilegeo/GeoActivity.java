package edu.ycp.cs.cs496.mobilegeo;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import edu.ycp.cs.cs496.mobileclient.R;
import edu.ycp.cs496.lab01.json.JSON;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class GeoActivity extends Activity {

    /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);
       
       // Set click listener for button
       final Button distanceButton = (Button) findViewById(R.id.distanceButton);
       distanceButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(distanceButton.getWindowToken(), 0);
				
				// Access web service when button is clicked 
				try {
					CallWebService();
				} catch (Exception e) {
					e.printStackTrace();
				}				
			}
		});
   }
 
   // Button click handler
   public void CallWebService() throws URISyntaxException, ClientProtocolException, IOException {
	   	// TODO: Get edit text control objects
	    EditText firstStreet = (EditText) findViewById(R.id.firstStreet);

	   
	    // Create HTTP client object
	   	HttpClient client = new DefaultHttpClient();
	   
   		// Create list for parameters
		List<NameValuePair> params = new ArrayList<NameValuePair>();	   

		// TODO: Add parameter key/value pairs for first address

		
		// Send GET request for first address
		URI uri1 = URIUtils.createURI("http", "api.geonames.org", -1, "/postalCodeSearchJSON", 
				    URLEncodedUtils.format(params, "UTF-8"), null);
		HttpGet request1 = new HttpGet(uri1);
		HttpResponse response1 = client.execute(request1);

		// Process response for first address (if valid)
		HttpEntity entity1 = response1.getEntity();

		// TODO: Get PostalCodes object for first address
		
		
		// TODO: Add parameter key/value pairs for second address

		
		// Send GET request for second address
		URI uri2 = URIUtils.createURI("http", "api.geonames.org", -1, "/postalCodeSearchJSON", 
				    URLEncodedUtils.format(params, "UTF-8"), null);
		HttpGet request2 = new HttpGet(uri2);
		HttpResponse response2 = client.execute(request2);

		// Process response for second address (if valid)
		HttpEntity entity2 = response2.getEntity();

		// TODO: Get PostalCodes object for second address
		
		// TODO: Create controller and compute Result object with distance
		
		// TODO: Set distance in label widget 

   
   }
}
