package edu.ycp.cs.cs496.cs496_lab06;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Salutations extends Activity {

    	private String title;
    	private String salutationMsg;

    	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        // Use for linear layout
	        setContentView(R.layout.activity_main);
	        // Use for relative layout
	        //setContentView(R.layout.activity_main_rel);
	 
	        title = "";
	        salutationMsg = "";
	                
	        // TODO: Populate spinner
	        
	        // TODO: Button callback
	        final Button button = (Button) findViewById(R.id.salutationButton);
	        button.setOnClickListener(new View.OnClickListener() {
	                @Override
	                public void onClick(View v) {
	                	// TODO: Check name CheckBoxes

	                	// TODO: Get first name text
	        			
	        			// TODO: Get last name text

	                	// TODO: Check for errors
	                		
	                	// TODO: Construct toast message for salutation
	                	String msg = "";
	                	Toast.makeText(Salutations.this, msg, Toast.LENGTH_LONG).show();
	                }
	        });
	    }
	    	    
	    // Title Spinner selection listener
	    public class TitleSelectedListener implements OnItemSelectedListener {
	        // Item selected
	        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
	        	// TODO: Add text to title based on selected object
	        	
	        }

	        // Nothing selected
	        public void onNothingSelected(AdapterView<?> parent) {
	            // TODO: Set text for title appropriately if no item selected

	        }
	    }
	    
    	// Salutation RadioButton group callback
	    public void onSalutationClicked(View v) {
	        // TODO: Get radio button selected
	    	
	        // TODO: Add appropriate text to salutationMsg

	    }    

	    // First name CheckBox callback
	    public void onFirstNameClicked(View v) {
	        // Check if box is set or not
	    	CheckBox cb = (CheckBox) v;
	        if (cb.isChecked()) {
	        	
	        } else {
	            
	        }
	    }
	    
	    // Last name CheckBox callback
	    public void onLastNameClicked(View v) {
	        // Check if box is set or not
	        CheckBox cb = (CheckBox) v;
	        if (cb.isChecked()) {
	        	
	        } else {
	            
	        }
	    }

}
