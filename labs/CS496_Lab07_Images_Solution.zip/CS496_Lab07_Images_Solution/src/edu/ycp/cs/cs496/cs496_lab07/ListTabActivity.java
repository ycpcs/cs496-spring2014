package edu.ycp.cs.cs496.cs496_lab07;

import java.util.List;
import java.util.Vector;

import android.net.ParseException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;

public class ListTabActivity extends ListActivity {
    private LayoutInflater mInflater;
    private Vector<RowData> data;
    RowData rd;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.list_layout);
    	mInflater = (LayoutInflater) getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
    	data = new Vector<RowData>();
    	for(int i=0;i<title.length;i++){

    		try {
    		 	rd = new RowData(i,title[i]);
    		} catch (ParseException e) {
    		    	e.printStackTrace();
    		}
    		data.add(rd);
    	}
    	CustomAdapter adapter = new CustomAdapter(this, R.layout.list,
    		                                     R.id.title, data);
    	setListAdapter(adapter);
    	getListView().setTextFilterEnabled(true);
    }
    		   
    public void onListItemClick(ListView parent, View v, int position,long id) {        	

    		   Toast.makeText(getApplicationContext(), "You have selected "
    		                    + title[position],  Toast.LENGTH_SHORT).show();
    }
    	
    private class RowData {
    	protected int mId;
    	protected String mTitle;
    	
    	RowData(int id,String title){
    		mId=id;
    		mTitle = title;
    	}
    	@Override
    	public String toString() {
            return mId+" "+mTitle;
    	}
    }
    
    private class CustomAdapter extends ArrayAdapter<RowData> {

    	  public CustomAdapter(Context context, int resource,
    	                        int textViewResourceId, List<RowData> objects) {               

    		  super(context, resource, textViewResourceId, objects);
    	  }
    	      
    	  @Override
    	  public View getView(int position, View convertView, ViewGroup parent) {   

    	       ViewHolder holder = null;
    	       TextView title = null;
    	       ImageView i11=null;
    	       RowData rowData= getItem(position);
    	       if(null == convertView){
    	            convertView = mInflater.inflate(R.layout.list, null);
    	            holder = new ViewHolder(convertView);
    	            convertView.setTag(holder);
    	       }
    	       holder = (ViewHolder) convertView.getTag();
    	       title = holder.gettitle();
    	       title.setText(rowData.mTitle);

    	       i11=holder.getImage();
    	       i11.setImageResource(imgid[rowData.mId]);
    	       return convertView;
    	  }
    }
    
    private class ViewHolder {
    	private View mRow;
    	private TextView title = null;
    	private ImageView i11=null; 

    	public ViewHolder(View row) {
    		mRow = row;
    	}
    	public TextView gettitle() {
    		if(null == title){
    			title = (TextView) mRow.findViewById(R.id.title);
    		}
    		return title;
    	}     

    	public ImageView getImage() {
    		if(null == i11){
    			i11 = (ImageView) mRow.findViewById(R.id.img);
            }
    		return i11;
    	}
    }
    
    // references to our images
    private Integer[] imgid = {
            R.drawable.belgium, R.drawable.bulgaria,
            R.drawable.canada, R.drawable.croatia,
            R.drawable.czechrepublic, R.drawable.denmark,
            R.drawable.estonia, R.drawable.france,
            R.drawable.germany, R.drawable.greece,
            R.drawable.hungary, R.drawable.iceland,
            R.drawable.italy, R.drawable.latvia,
            R.drawable.lithuania, R.drawable.luxembourg,
            R.drawable.netherlands, R.drawable.norway,
            R.drawable.poland, R.drawable.portugal,
            R.drawable.romania, R.drawable.slovakia,
            R.drawable.slovenia, R.drawable.spain,
            R.drawable.turkey, R.drawable.unitedkingdom,
            R.drawable.unitedstates           
    };
    
    // references to our images
    static final String[] title = {
            "Belgium", "Bulgaria",
            "Canada", "Croatia",
            "Czech Republic", "Denmark",
            "Estonia", "France",
            "Germany", "Greece",
            "Hungary", "Iceland",
            "Italy", "Latvia",
            "Lithuania", "Luxembourg",
            "Netherlands", "Norway",
            "Poland", "Portugal",
            "Romania", "Slovakia",
            "Slovenia", "Spain",
            "Turkey", "United Kingdom",
            "United States"           
    };
}
