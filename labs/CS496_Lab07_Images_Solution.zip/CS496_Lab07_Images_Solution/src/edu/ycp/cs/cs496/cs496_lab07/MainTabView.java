package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.view.Menu;
import android.widget.TabHost;

public class MainTabView extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

        // Get resources for the activity
        Resources res = getResources();

        // Get TabHost for the activity
        TabHost tabHost = getTabHost();

        // Create TabSpec object
        TabHost.TabSpec tabSpec;

        // Create Intent object
        Intent tabIntent;

        // Create first tab
        tabIntent = new Intent().setClass(this, ListTabActivity.class);
        tabSpec = tabHost.newTabSpec("listtab").setIndicator("List", res.getDrawable(R.drawable.ic_tab1)).setContent(tabIntent);
        tabHost.addTab(tabSpec);

        // Create second tab
        tabIntent = new Intent().setClass(this, GridTabActivity.class);
        tabSpec = tabHost.newTabSpec("gridtab").setIndicator("Grid", res.getDrawable(R.drawable.ic_tab1)).setContent(tabIntent);
        tabHost.addTab(tabSpec);

        // Select first tab initially
        tabHost.setCurrentTab(0);
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_tab_view, menu);
		return true;
	}

}
