package edu.ycp.cs.cs496.cs496_lab07;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {
    private Context mContext;

    public ImageAdapter(Context c) {
        mContext = c;
    }

    public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return position;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {  // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(44, 30));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
            R.drawable.belgium, R.drawable.bulgaria,
            R.drawable.canada, R.drawable.croatia,
            R.drawable.czechrepublic, R.drawable.denmark,
            R.drawable.estonia, R.drawable.france,
            R.drawable.germany, R.drawable.greece,
            R.drawable.hungary, R.drawable.iceland,
            R.drawable.italy, R.drawable.latvia,
            R.drawable.lithuania, R.drawable.luxembourg,
            R.drawable.netherlands, R.drawable.norway,
            R.drawable.poland, R.drawable.portugal,
            R.drawable.romania, R.drawable.slovakia,
            R.drawable.slovenia, R.drawable.spain,
            R.drawable.turkey, R.drawable.unitedkingdom,
            R.drawable.unitedstates           
    };
}
