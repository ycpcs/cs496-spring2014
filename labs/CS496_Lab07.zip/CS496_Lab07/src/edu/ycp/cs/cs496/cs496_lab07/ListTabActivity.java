package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.app.Activity;

public class ListTabActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: Remove following line
        setContentView(R.layout.list_layout);

        // TODO: Create String array from countries resource
        
        // TODO: Create ListAdapter using list_item layout and string array

        // TODO: Get list view resource

        // TODO: Register click callback for list view and display Toast message in onItem() method
	
	}

}
