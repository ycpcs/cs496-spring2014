package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.view.Menu;
import android.widget.TabHost;

public class MainTabView extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	    // TODO: Get resources for the activity

        // TODO: Get TabHost for the activity

        // TODO: Create TabSpec object

        // TODO: Create Intent object

        // TODO: Create first tab

        // TODO: Create second tab

        // TODO: Select first tab initially

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_tab_view, menu);
		return true;
	}

}
