package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.app.Activity;

public class GridTabActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.grid_layout);

		// TODO: Get GridView reference

        // TODO: Create String array from countries resource
        
        // TODO: Create ArrayAdapter using list_item layout and string array

        // TODO: Set array adapter to grid view
		
        // TODO: Register click callback for grid view and display Toast message in onItemClick() method
	
	}	
}
