package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.app.Activity;

public class GridTabActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.grid_layout);

		// Get GridView reference
		GridView gv = (GridView) findViewById(R.id.gridview);

        // Create String array from countries resource
        final String[] gridArray = getResources().getStringArray(R.array.countries);
        
        // TODO: Set ImageAdapter to grid view

        
        // Register click callback for grid view and display Toast message in onItemClick() method
		gv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
				Toast.makeText(GridTabActivity.this, "You selected "+ gridArray[pos],Toast.LENGTH_SHORT).show();
			}
		});
	
	}	
}
