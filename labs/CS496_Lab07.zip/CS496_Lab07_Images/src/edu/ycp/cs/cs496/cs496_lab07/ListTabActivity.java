package edu.ycp.cs.cs496.cs496_lab07;

import java.util.List;
import java.util.Vector;

import android.net.ParseException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;

public class ListTabActivity extends ListActivity {
	private String[] countryStrings;
	
	// Private fields for creating custom row views
	private LayoutInflater mInflater;
    private Vector<RowData> data;
    RowData rd;

    // References to images
    private Integer[] imgid = {
            R.drawable.belgium, R.drawable.bulgaria,
            R.drawable.canada, R.drawable.croatia,
            R.drawable.czechrepublic, R.drawable.denmark,
            R.drawable.estonia, R.drawable.france,
            R.drawable.germany, R.drawable.greece,
            R.drawable.hungary, R.drawable.iceland,
            R.drawable.italy, R.drawable.latvia,
            R.drawable.lithuania, R.drawable.luxembourg,
            R.drawable.netherlands, R.drawable.norway,
            R.drawable.poland, R.drawable.portugal,
            R.drawable.romania, R.drawable.slovakia,
            R.drawable.slovenia, R.drawable.spain,
            R.drawable.turkey, R.drawable.unitedkingdom,
            R.drawable.unitedstates           
    };
    
   /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.list_layout);
    	
        // Create String array from countries resource
        countryStrings = getResources().getStringArray(R.array.countries);

        // TODO: Create custom row layouts
    }
    		   
    public void onListItemClick(ListView parent, View v, int position,long id) {        	

    		   Toast.makeText(getApplicationContext(), "You have selected "
    		                    + countryStrings[position],  Toast.LENGTH_SHORT).show();
    }
 
    // TODO: Add RowData class definition
 
    // TODO: Add CustomAdapter class definition

    // TODO: Add ViewHolder class definition

}
