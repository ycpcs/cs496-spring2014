package edu.ycp.cs496.lab01.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonParseException;

import edu.ycp.cs496.lab01.controllers.PerformOperation;
import edu.ycp.cs496.lab01.json.JSON;
import edu.ycp.cs496.lab01.model.Operation;
import edu.ycp.cs496.lab01.model.OperationType;
import edu.ycp.cs496.lab01.model.Result;

public class Op extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO: implement this
		resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		resp.setContentType("text/plain");
		resp.getWriter().println("Sorry, this isn't implemented yet");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO: implement this
		resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		resp.setContentType("text/plain");
		resp.getWriter().println("Sorry, this isn't implemented yet");
	}
}
