package edu.ycp.cs.cs496.cs496_lab07;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.app.ListActivity;

public class ListTabActivity extends ListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: Remove following line
        //setContentView(R.layout.list_layout);

        // TODO: Create String array from countries resource
        String[] listArray = getResources().getStringArray(R.array.countries);
        
        // TODO: Create ListAdapter using list_item layout and string array
        ListAdapter listAdapter = new ArrayAdapter<String>(this, R.layout.list_item, listArray);
        setListAdapter(listAdapter);

        // TODO: Get list view resource
        ListView lv = getListView();
        lv.setTextFilterEnabled(true);

        // TODO: Register click callback for list view and display Toast message in onItemClick() method
        lv.setOnItemClickListener(new OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
    				Toast.makeText(ListTabActivity.this, "You selected "+ ((TextView) view).getText(),Toast.LENGTH_LONG).show();
                }
        });

	}

}
