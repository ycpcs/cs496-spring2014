package edu.ycp.cs.cs496.mobileclient;

import java.io.IOException;
import java.net.URISyntaxException;
import org.apache.http.client.ClientProtocolException;
import edu.ycp.cs.cs496.mobilecontroller.MobileController;
import edu.ycp.cs496.lab05.model.Result;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

    /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);
       
       final Button distanceButton = (Button) findViewById(R.id.distanceButton);

       // Add click listener for distance button
       distanceButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(distanceButton.getWindowToken(), 0);
				
				// TODO Auto-generated method stub
				try {
					// Call click handler to process request
					ProcessRequest();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
		});
   }
   
   public void ProcessRequest() throws URISyntaxException, ClientProtocolException, IOException{
       // TODO: Get UI widget references
       EditText firstStreet = (EditText) findViewById(R.id.firstStreet);

       // TODO: Instantiate controller and compute distance

       // TODO: If result is valid, display result
   }
}
