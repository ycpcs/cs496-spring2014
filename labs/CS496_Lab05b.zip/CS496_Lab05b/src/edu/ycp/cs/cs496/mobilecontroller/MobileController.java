package edu.ycp.cs.cs496.mobilecontroller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import edu.ycp.cs496.lab01.json.JSON;
import edu.ycp.cs496.lab05.controllers.ComputeDistance;
import edu.ycp.cs496.lab05.model.PostalCodes;
import edu.ycp.cs496.lab05.model.Result;

public class MobileController {
	public Result getGeoDistance(String firstStreet, String firstZip, String secondStreet, String secondZip) 
			throws URISyntaxException, ClientProtocolException, IOException
	{
		Result r = null;
		
		// TODO: Make get request for first address
		
		// TODO: Make get request for second address
		
		// TODO: Both requests returned valid info so compute result

		// Otherwise return null
		return r;
	}
	
	private PostalCodes makeGeoGetRequest(String street, String zip) throws URISyntaxException, ClientProtocolException, IOException
	{
		// Create HTTP client
 		HttpClient client = new DefaultHttpClient();

 		// TODO: Create list of request paramater/value pairs
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		
		// Construct URI
		URI uri;
		uri = URIUtils.createURI("http", "api.geonames.org", -1, "/postalCodeSearchJSON", 
				    URLEncodedUtils.format(params, "UTF-8"), null);

		// Make get request
		HttpGet request = new HttpGet(uri);
		HttpResponse response;
		response = client.execute(request);
		
		// Parse response if valid
		if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
			// Copy the response body to a string
			HttpEntity entity = response.getEntity();
			
			// TODO: Parse JSON

		} 
		
		// Return null if invalid response
		return null;
	}
}
