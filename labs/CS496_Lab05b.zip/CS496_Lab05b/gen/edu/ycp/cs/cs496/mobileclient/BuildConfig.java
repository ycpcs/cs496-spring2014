/** Automatically generated file. DO NOT MODIFY */
package edu.ycp.cs.cs496.mobileclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}