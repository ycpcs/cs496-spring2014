package edu.ycp.cs496.fruit.controllers;

import java.util.List;

import edu.ycp.cs496.fruit.model.Item;
import edu.ycp.cs496.fruit.model.persist.Database;
import edu.ycp.cs496.fruit.model.persist.IDatabase;

/**
 * Controller to get the complete inventory (list of items).
 */
public class GetInventory {
	public List<Item> getInventory() {
		IDatabase db = Database.getInstance();
		return db.getInventory();
	}
}
