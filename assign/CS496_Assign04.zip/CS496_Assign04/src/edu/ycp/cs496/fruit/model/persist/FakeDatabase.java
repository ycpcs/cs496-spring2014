package edu.ycp.cs496.fruit.model.persist;

import java.util.ArrayList;
import java.util.List;

import edu.ycp.cs496.fruit.model.Item;

/**
 * Implementation of the {@link IDatabase} interface that stores
 * objects using in-memory data structures.  It doesn't
 * provide actual persistence, but is useful as a proof
 * of concept.
 */
public class FakeDatabase implements IDatabase {
	private List<Item> inventory;
	
	public FakeDatabase() {
		inventory = new ArrayList<Item>();
		
		// Populate initial inventory
		inventory.add(new Item("Apples", 3));
		inventory.add(new Item("Oranges", 7));
		inventory.add(new Item("Pomegranates", 55));
	}
	
	@Override
	public Item getItem(String itemName) {
		for (Item item : inventory) {
			if (item.getName().equals(itemName)) {
				// return a copy
				return new Item(item.getName(), item.getQuantity());
			}
		}
		
		// no such item
		return null;
	}

	@Override
	public List<Item> getInventory() {
		// return a copy
		return new ArrayList<Item>(inventory);
	}
}
