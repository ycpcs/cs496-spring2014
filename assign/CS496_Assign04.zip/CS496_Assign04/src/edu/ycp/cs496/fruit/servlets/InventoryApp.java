package edu.ycp.cs496.fruit.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ycp.cs496.fruit.controllers.GetInventory;
import edu.ycp.cs496.fruit.controllers.GetItemByName;
import edu.ycp.cs496.fruit.model.Item;

public class InventoryApp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String action = req.getParameter("action");
		if (action != null) {
			req.setAttribute("action", action);
		}
		String itemName = getItemName(req);
		showUI(req, resp, itemName);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String itemName = getItemName(req);
		String action = req.getParameter("action");
		if (action == null || action.trim().equals("")) {
			showUI(req, resp, itemName);
			return;
		}
		throw new ServletException("Unknown action: " + action);
	}

	public String getItemName(HttpServletRequest req) {
		String itemName = null;
		String pathInfo = req.getPathInfo();
		if (pathInfo != null && !pathInfo.equals("") && !pathInfo.equals("/")) {
			itemName = pathInfo;
			if (itemName.startsWith("/")) {
				itemName = itemName.substring(1);
			}
		}
		return itemName;
	}

	private void showUI(HttpServletRequest req, HttpServletResponse resp,
			String itemName) throws ServletException, IOException {
		if (itemName == null) {
			GetInventory controller = new GetInventory();
			List<Item> inventory = controller.getInventory();
			req.setAttribute("Inventory", inventory);
			req.getRequestDispatcher("/_view/inventory.jsp").forward(req, resp);
		} else {
			GetItemByName controller = new GetItemByName();
			Item item = controller.getItem(itemName);
			req.setAttribute("Item", item);
			req.getRequestDispatcher("/_view/item.jsp").forward(req, resp);
		}
	}
}
