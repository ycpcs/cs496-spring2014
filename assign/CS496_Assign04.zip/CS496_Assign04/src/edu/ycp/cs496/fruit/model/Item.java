package edu.ycp.cs496.fruit.model;

/**
 * Class to represent an inventory item.
 */
public class Item {
	private String name;
	private int quantity;

	/**
	 * Default constructor.
	 */
	public Item() {
		
	}
	
	/**
	 * Constructor.
	 * 
	 * @param name      item name
	 * @param quantity  item quantity
	 */
	public Item(String name, int quantity) {
		this.name = name;
		this.quantity = quantity;
	}
	
	/**
	 * Set the item name.
	 * 
	 * @param name the item name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Get the item name.
	 * 
	 * @return the item name.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Set the item quantity.
	 * 
	 * @param quantity the item quantity.
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * Get the item quantity.
	 * 
	 * @return the item quantity.
	 */
	public int getQuantity() {
		return quantity;
	}
}
