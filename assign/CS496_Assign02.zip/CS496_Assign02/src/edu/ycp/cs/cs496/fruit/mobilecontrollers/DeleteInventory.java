package edu.ycp.cs.cs496.fruit.mobilecontrollers;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.impl.client.DefaultHttpClient;

import edu.ycp.cs496.fruit.model.Item;

/**
 * Controller to get an {@link Item} given the item name.
 */
public class DeleteInventory {
	public boolean deleteInventory() throws URISyntaxException, ClientProtocolException, IOException {
		return makeDeleteRequest();
	}
	
	private boolean makeDeleteRequest() throws URISyntaxException, ClientProtocolException, IOException {
		// TODO: Implement method to issue delete inventory request
		
		return false;
	}
}
