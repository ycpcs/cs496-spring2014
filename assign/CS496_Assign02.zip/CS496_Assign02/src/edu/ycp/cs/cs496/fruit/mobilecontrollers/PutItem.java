package edu.ycp.cs.cs496.fruit.mobilecontrollers;

import java.io.IOException;
import java.net.URISyntaxException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import edu.ycp.cs496.fruit.model.Item;

/**
 * Controller to put an {@link Item} given the item name.
 */
public class PutItem {
	public boolean putItem(String itemName, int quantity) throws URISyntaxException, JsonGenerationException, JsonMappingException, IOException {
		return makePutRequest(itemName,quantity);
	}
	
	public boolean makePutRequest(String itemName, int quantity) throws URISyntaxException, JsonGenerationException, JsonMappingException, IOException {
		// TODO: Implement method to issue put request
		
		return false;
	}
}
