package edu.ycp.cs.cs496.fruit.mobilecontrollers;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.http.client.ClientProtocolException;
import edu.ycp.cs496.fruit.model.Item;

/**
 * Controller to get an {@link Item} given the item name.
 */
public class DeleteItem {
	public boolean deleteItem(String itemName) throws ClientProtocolException, URISyntaxException, IOException {
		return makeDeleteRequest(itemName);
	}
	
	private boolean makeDeleteRequest(String itemName) throws URISyntaxException, ClientProtocolException, IOException {
		// TODO: Implement method to issue delete item request
		
		return false;
	}
}
