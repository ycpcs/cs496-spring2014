package edu.ycp.cs.cs496.cs496_assign02;

import java.io.IOException;
import java.net.URISyntaxException;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.client.ClientProtocolException;
import org.xml.sax.SAXException;

import edu.ycp.cs.cs496.fruit.mobilecontrollers.GetInventory;
import edu.ycp.cs496.fruit.model.Item;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MobileInventoryClient extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDefaultView();
    }
        
    // TODO: Event handlers for get inventory, get single item, put, post, delete single item
    //       and delete entire inventory
    public void getInventory() throws URISyntaxException, ClientProtocolException,
	IOException, ParserConfigurationException, SAXException{
		GetInventory ic = new GetInventory();
		Item[] items = ic.getInventory();
		if (items != null) {
			displayInventoryView(items);
		} else {
			Toast.makeText(MobileInventoryClient.this, "INVENTORY NOT FOUND!", Toast.LENGTH_SHORT).show();
		}
    }
    

    
    // Method for displaying data entry view
    public void setDefaultView() {
        setContentView(R.layout.activity_main);
        
        // TODO: Obtain references to widgets
        Button showButton = (Button) findViewById(R.id.showButton);
        
        // TODO: Set onClickListeners for buttons
        showButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					getInventory();
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
    }
    
    // Method for displaying inventory list
    public void displayInventoryView(Item[] inventory) {
		// Create Linear layout
		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.FILL_PARENT);

		// Add back button
		Button backButton = new Button(this);
		backButton.setText("Back");
		backButton.setLayoutParams(new LayoutParams(
				LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));
		// TODO: Add back button onClickListener

		// Add button to layout
		layout.addView(backButton);

		// TODO: Add ListView with inventory
		
		// Make inventory view visible
		setContentView(layout,llp);    	
    }
    
}
