package edu.ycp.cs.cs496.fruit.mobilecontrollers;

import java.io.IOException;
import java.net.URISyntaxException;
import org.apache.http.client.ClientProtocolException;
import edu.ycp.cs496.fruit.model.Item;

/**
 * Controller to get an {@link Item} given the item name.
 */
public class GetItem {
	public Item getItems(String itemName) throws ClientProtocolException, URISyntaxException, IOException {
		return makeGetRequest(itemName);
	}
	
	private Item makeGetRequest(String itemName) throws URISyntaxException, ClientProtocolException, IOException
	{
		// TODO: Implement method to issue get item request
		
		// Return null if invalid response
		return null;
	}

}
